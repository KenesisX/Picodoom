# Try Pico Doom - Android / Google Play build

A full-screen WebView wrapper around the bundled HTML5 game (`app/src/main/assets/index.html`).
Package: `com.strikebacktech.trypicodoom` | minSdk 24 | target/compile SDK 36 | landscape | works fully offline
(INTERNET permission is only for optional online multiplayer + share links).

> **Status:** the project files were written and checked for syntax, but the build itself could not be run where this
> was made (no Android SDK access). Your first GitHub Actions run is the real test - if it reports an error, send me the
> log and I'll fix it.

## Easiest: build the signed AAB on GitHub (no Android Studio needed)
1. Create your upload key once, on your own computer: `cd android && ./gen-keystore.sh` (needs Java). **Back up `release.keystore` and its passwords.**
2. In your GitHub repo: Settings > Secrets and variables > Actions > add
   `ANDROID_KEYSTORE_BASE64` (output of `base64 -w0 release.keystore`), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS` (`trypicodoom`), `ANDROID_KEY_PASSWORD`.
3. Actions tab > **Android AAB (Google Play)** > Run workflow. Download the `trypicodoom-aab` artifact = `app-release.aab`.
   (It also produces a `trypicodoom-debug-apk` you can sideload to test on a phone first.)

## Or build locally (Android Studio / command line)
```
cd android
export KEYSTORE_FILE=$PWD/release.keystore KEYSTORE_PASSWORD=... KEY_ALIAS=trypicodoom KEY_PASSWORD=...
./gradlew bundleRelease          # -> app/build/outputs/bundle/release/app-release.aab
```
Bump `versionCode` in `app/build.gradle` for every new upload.

## Updating the game
Copy a new build of the game over `app/src/main/assets/index.html` (the store copy hides the Cash App wagering UI;
re-apply that one change when you replace it - see `store/policy-notes.md`), bump `versionCode`, rebuild.

## Online play / leaderboard
Set `const MP_DEFAULT='your-app.ondigitalocean.app'` near the top of the "ONLINE v2" block in
`app/src/main/assets/index.html` (search for `MP_DEFAULT`) so Quick Play works with no typing. The free option is `../cloudflare/README.md` (host looks like `trypicodoom.yourname.workers.dev`).
Leaderboard sends only the player's chosen name and score, and only when a server host is configured.

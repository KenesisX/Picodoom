#!/usr/bin/env bash
# Run ONCE on your own computer. Creates your Play UPLOAD key. Back up release.keystore + the passwords somewhere safe
# (password manager + offline copy). Google Play App Signing protects you if you lose it, but resetting takes days.
set -e
keytool -genkeypair -v -keystore release.keystore -alias trypicodoom -keyalg RSA -keysize 2048 -validity 10000 \
  -dname "CN=Strikeback Tech LLC, O=Strikeback Tech LLC, L=Colorado, C=US"
echo
echo "Now add these GitHub repo secrets (Settings > Secrets and variables > Actions):"
echo "  ANDROID_KEYSTORE_BASE64   = $(base64 -w0 release.keystore | cut -c1-20)...  (run: base64 -w0 release.keystore)"
echo "  ANDROID_KEYSTORE_PASSWORD = the store password you just typed"
echo "  ANDROID_KEY_ALIAS         = trypicodoom"
echo "  ANDROID_KEY_PASSWORD      = the key password you just typed"

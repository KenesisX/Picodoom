# Platforms

Try Pico Doom targets four places. Android, Raspberry Pi and desktop run the full game (`../server/public/index.html`); the RP2040 PicoSystem runs the native engine (`../main.cpp`):

| Platform | How |
|---|---|
| **Android** | `../android/` (WebView app locked to **portrait**: game on top, touch controls underneath so they never cover the picture; APK + Play Store AAB built by GitHub Actions) |
| **Raspberry Pi 4/5** | `pi/pi-kiosk.sh` (fullscreen Chromium kiosk in landscape, 640x400 render by default, optional start on boot) |
| **RP2040 PicoSystem** | `../build.sh` or the `rp2040` job in the workflow builds `trypicodoom-picosystem.uf2`; drag it onto the RPI-RP2 drive |
| **Desktop** | landscape, 640x400 render by default (320x200 and 960x600 in the menu); open `trypicodoom.html` or use the launchers in `desktop/` |

`flasher/index.html` is the downloads page published by `.github/workflows/firmware.yml`.

The ESP32 and Cardputer builds (`esp32/`, `cardputer/`) compile the same `../main.cpp`, so they get the RP2040 updates too (landscape displays). They are not part of the release workflow and do not have the web-only features (city levels, cutscenes, floors, scope zoom).

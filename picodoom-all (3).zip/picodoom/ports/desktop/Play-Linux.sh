#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"; G="$DIR/trypicodoom.html"
[ -f "$G" ] || { echo "Put trypicodoom.html next to this file."; exit 1; }
for b in google-chrome chromium chromium-browser microsoft-edge; do command -v $b >/dev/null && exec $b --app="file://$G?q=auto" --start-fullscreen --ignore-gpu-blocklist --enable-gpu-rasterization --enable-zero-copy --autoplay-policy=no-user-gesture-required; done
exec xdg-open "$G"

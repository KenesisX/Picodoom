#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
[ -f "$DIR/trypicodoom.html" ] || { echo "Put trypicodoom.html next to this file."; exit 1; }
open -na "Google Chrome" --args --app="file://$DIR/trypicodoom.html?q=auto" --start-fullscreen --ignore-gpu-blocklist --enable-gpu-rasterization --autoplay-policy=no-user-gesture-required 2>/dev/null || open "$DIR/trypicodoom.html"

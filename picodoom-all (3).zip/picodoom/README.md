# Try Pico Doom

A Doom-style first-person shooter that runs in any browser. One file, no install, works offline.
**36 levels across 6 biomes (downtown, city park, forest, mall, desert, nuclear reactor), 32 weapons, demon seals, 9 bosses, multi-floor towers, a motorcycle, a turret, spells, melee, third-person view and 2-4 player online.**

Built by Kenesis_X / Strikeback Tech LLC. Original code and art, no id Software assets.

| Platform | How to get it |
|---|---|
| **Android** | `android/` project (portrait layout). GitHub Actions builds an installable APK and a Play Store AAB. |
| **Raspberry Pi 4/5** | `ports/pi/pi-kiosk.sh` runs it fullscreen, optionally on boot. |
| **Desktop** (Windows, Mac, Linux) | Open `trypicodoom.html` in any browser, or use `ports/desktop/` launchers. |
| **Online play** | Free Cloudflare server in `cloudflare/` (details below). |

![menu](docs/shots/02-menu.jpg)

---

## 1. First launch

### Photosensitivity warning
Every launch opens with a warning screen. It has a **Reduce flashing effects** box, ticked by default. Leave it ticked if you are sensitive to flashing. To change it later, reload the game and the screen appears again.

With it ticked the game: softens or removes screen-wide flashes (damage, muzzle, lightning), removes the random dark flicker and noise, skips the jump-scare image, stops the menu background pulsing and slows the title fire.

![warning](docs/shots/01-warning.jpg)

### Mature rating screen
After the warning comes a **M - MATURE 17+** screen listing the content: blood and gore, intense fantasy violence, strong language, suggestive themes and drug references. It is a self-assigned rating, not an official ESRB or PEGI one. For Google Play, answer the IARC questionnaire honestly with the same descriptors.

### Scope zoom (0 to 100x)
Hold **right mouse** (or the scope button) to aim down the scope, then change the zoom from 1x to **100x** with the **mouse wheel**, **+ / -** (or **[ / ]**), or the on-screen **+ / -** buttons on touch screens. **9** jumps straight to 100x. The zoom level is shown under the crosshair and is remembered. Turning slows as you zoom so you can aim. Items to try: **Rail gun** at 60x across a street.

![zoom 12x](docs/shots/27-scope-zoom-12x.jpg)
![zoom 60x](docs/shots/28-scope-zoom-60x.jpg)

### Cover: enemy shots hit what is in the way
Fireballs, bullets and thrown projectiles from enemies are now stopped by walls, crates, barrels, props, cars and **other enemies**. Stand behind a barrel or another monster and it takes the hit instead of you (an enemy shot by a friend takes 70 percent damage). Explosive shots still explode where they land.

### MAX VIGOR machine and Rage mode
A **MAX VIGOR vending machine** sits in the far corner of every level (the bottom-right corner on city levels). Walk up to it to take a pill packet: **Rage mode for 14 seconds** with double damage, rapid fire and brief invulnerability, plus +40 health and +40 ammo. The screen tints red while it lasts. One use per level.

![vigor](docs/shots/34-vigor-rage.jpg)

### Ammo boxes
Every ammo box (the green crates and the pickup) now carries a **demonic pentagram**.

![ammo](docs/shots/26-demonic-ammo-boxes.jpg)

### Screen layout and resolution
- **Android** runs in **portrait**. The game fills the top of the screen, the touch controls sit in their own panel underneath (so they never cover the picture), and there is a **drag-to-look pad** at the bottom. Menus use the whole screen.
- **Raspberry Pi and desktop** run in landscape. The 3D view now renders at **640x400** by default (double the old 320x200). The main menu has a **RESOLUTION** row: 320x200, 640x400 or 960x600. Add `?res=1`, `?res=2` or `?res=3` to the page address to force one (the Pi kiosk script uses `?res=2`). If the frame rate drops, the game lowers the resolution one step on its own and tells you.
- **RP2040 PicoSystem** runs the native build (`main.cpp`) with: smoother wall sliding (no snagging), Knife Junkies and Gang Zombies, enemy shots stopped by other monsters, and a MAX VIGOR rage pickup in the far corner. City levels, cutscenes and scope zoom are web only.

### Main menu options
- **NORMAL / HALLOWEEN**: Halloween swaps the level palette and enemy set.
- **EASY / MEDIUM / HARD / IMPOSSIBLE** (see section 9).
- **NEW GAME**, **CONTINUE** (shows when a save exists), **ONLINE (2-4 PLAYERS)**.
- **CHARACTER**: guy or girl, 6 suit colors, helmet / gas mask / both, 12 outfits (soldier, ninja, gangster, police officer, firefighter, drug dealer, crack head, lawyer, assassin, construction worker and more), 6 hats.
- **CHEAT CODES** (type in the box, then ENTER): `KENESIS` unlimited ammo and all guns, `X` unlimited health, `FUCK IT` the four heavy weapons, `CRAZY` double speed with a fire trail, `SEXY` bouncing bullets with heal-per-hit and flirty kill lines.
- **MUSIC**: many 8-bit and modern tracks, plus **UPLOAD YOUR OWN** and an editable lyrics box (saved on your device).

---

## 2. Controls (keyboard)

| Key | Action |
|---|---|
| **W / S / Arrows up, down** | Walk forward / back |
| **A / D** | Strafe left / right |
| **Arrows left, right** | Turn |
| **R / F** or **PgUp / PgDn** | Look up / down |
| **Space / Ctrl / Z** | Fire |
| **Shift** | Run |
| **C** | Jump |
| **X** | Crouch (steadier aim, smaller target) |
| **B** | Scope (sniper and AK) |
| **V** | Energy shield (drains the shield bar) |
| **1-9**, **Q / E** | Pick weapon / previous or next weapon |
| **G** | Drop and arm a bomb |
| **H** | Throw a grenade from inventory |
| **N** | Throw a ninja star |
| **U** | Nuke (clears the screen) |
| **L** | Place a mine |
| **T** | Flamethrower (needs the flame attachment and fuel) |
| **J / K** | Punch / kick (every 4th punch is an uppercut) |
| **Y** | Cast the selected spell |
| **Tab** | Next spell |
| **O** or **0** | Toggle third-person camera |
| **I** | Minimap: off / small / big |
| **M** | Use: ride the motorcycle, mount the turret, get off |
| **P / Esc** | Pause |

On Android the game shows touch buttons for move, turn, fire, jump, melee, spell, ride, camera and map.

---

## 3. Reading the screen

- **Top left**: portrait (shows damage), **EVIL** meter (rises as you kill, boosts speed and damage but also damage taken), spell icons with a mana bar.
- **Top center**: short messages. They are small on purpose and fade quickly, so they never cover the action.
- **Top right**: minimap. On IMPOSSIBLE it says NO MAP.
- **Bottom bar**: HP, ARMOR, SHIELD, weapon name and ammo, level, difficulty, kills, keycards.
- **Boss bar**: appears at the top when a boss is awake.
- **Floor indicator** (bottom right): `FLOOR 2/3` on multi-floor levels.

![small message](docs/shots/04-level-start-small-message.jpg)

---

## 4. The levels and the tower

Each level is a set of **large rooms** joined by corridors (fewer rooms, fewer objects, more space than older versions so you can see what is happening). Doors need colored **keycards** (red, blue, yellow, green, purple). The **portal/exit** ends the level, but a **boss guards it** and the exit stays hidden until the boss dies.

Levels have 1 to 4 floors (`1 + level mod 4`). The exit is always on the top floor. Online co-op uses one floor.

| Feature | How it works |
|---|---|
| **Stairs** (up/down markers) | Walk in to change floor, with a fade. |
| **Escalators** | Step on and ride up or down. |
| **Elevator** | Pick any floor from a menu. |
| **Ladders** (free-standing) | Walk into one to climb to the next floor up (or down, if it points down). |
| **Slides** (orange chute) | One-way trip to the floor below, landing at a landing pad. Fast way down. |
| **Trampolines** (blue discs) | Launch you about 3 units up. Use them to reach loot on crate stacks and to hop over trouble. |
| **Conveyor belts** (yellow chevrons) | Push you and monsters in the arrow direction. Run against them to hold position. |
| **Crate ladders and platforms** | Climb onto crates for high ground and for loot chests ("LOOT FROM ON HIGH"). |
| **Armory** | Spend EP (earned by kills) on weapons, attachments and upgrades. |
| **Hazards** | Lava, acid and fire patches, acid rain on some levels. |

| | |
|---|---|
| ![trampoline](docs/shots/11-trampoline.jpg) | ![in the air](docs/shots/12-trampoline-air.jpg) |
| ![ladder](docs/shots/14-ladder.jpg) | ![slide](docs/shots/17-slide.jpg) |
| ![escalator](docs/shots/15-escalator.jpg) | ![elevator](docs/shots/16-elevator.jpg) |

![conveyor](docs/shots/13-conveyor.jpg)

---

### Downtown city levels (every third level)
Levels 2, 5, 8, 11 and so on are **city levels**: an 88x88 block of streets with stop signs, street lamps, hydrants, trash cans, parks with trees and benches, parking lots, and lit windows you can shoot out. You can walk into the stores (the doors open as you approach):

- **Ice cream shop** with freezer cases and tables.
- **Burger and pizza shops** with food-court tables, kiosks and vending machines.
- **Love Shop** (an adult novelty boutique, shown only as a neon sign, shelves of gift boxes and mannequins; nothing explicit is drawn).
- **Ammo and Pawn** with ammo boxes, a weapon pickup and bombs.
- **Dive bar** with bottle racks, stools and patrons.
- **The mall and food court** in the far corner. The exit and the boss are inside.

Everything that is alive can be killed, and almost everything that is not can be broken: windows, signs, lamps, hydrants, vending machines (they drop ammo or health), shelves, ATMs and cars. **Cars drive the streets and run you over** (32 damage and a shove) and also run over zombies and pedestrians. Pedestrians (all adults) wander and flee when you fire. Shooting a car makes it explode and leave a fire.

![city](docs/shots/21-city-street.jpg)
![ice cream](docs/shots/22-city-ice-cream.jpg)
![shop](docs/shots/23-city-shop-interior.jpg)
![mall](docs/shots/24-city-mall.jpg)

### Intro and level cards
The game opens with a demon face that says "Abandon hope all ye who enter here..." (tap or Space skips it).

![demon face](docs/shots/39-intro-demon-face.jpg)

Before the game and before every next level you see a single still picture of a character from the game (an imp, a lost soul, the nurse in Halloween in Hell, and so on) with the level number. There are no story scenes. Tap, Space or Enter continues, or it continues by itself after about three seconds.

![level card](docs/shots/38-level-card.jpg)

## 4b. Biomes, wildlife and demon seals

Every third level is a special biome (levels 2, 5, 8, 11, 14, 17, then the cycle repeats). Biomes are single-player only.

| Level | Biome | What is there |
|---|---|---|
| 2, 20 | **Downtown** | Streets, traffic lights that cycle red, green and yellow, cars that run you over, shops you can enter, a skyline and a sunny sky. Zombies chase and eat the pedestrians (some of them get up as zombies). |
| 5, 23 | **City park** | Lots of trees and benches, a few shops, wide open grass under the sky. |
| 8, 26 | **Roosevelt Forest** | Pine and aspen trunks you cannot walk through, boulders, ferns, logs, a mulchy dark floor, dusk sky with mountains. Hostile wildlife: coyote, fox, deer, elk, moose, black bear, mountain lion and ravens. |
| 11, 29 | **The Galleria** | An indoor mall: marble walls, storefronts, food court, shoppers. |
| 14, 32 | **Desert** | No ceiling, sand and sandstone mesas, adobe ruins with loot, cactus, bones, a big sun. Coyotes, mountain lions and ravens. |
| 17, 35 | **Nuclear reactor** | Concrete and hazard-stripe walls, green glow, acid pools, explosive radiation barrels and a glowing reactor core in the biggest room. |

![downtown](docs/shots/40-biome-downtown.jpg)
![park](docs/shots/41-biome-park.jpg)
![forest](docs/shots/42-biome-forest.jpg)
![mall](docs/shots/43-biome-mall.jpg)
![desert](docs/shots/44-biome-desert.jpg)
![reactor](docs/shots/45-biome-reactor.jpg)

### Demon seals
Glowing sigils (inspired by the Lesser Key of Solomon, the Dictionnaire Infernal and Enochian magic) are painted on walls, or stand as stones in the open biomes. Gold, blue and white seals are only decoration. **Red seals are demon seals.** Walk within about four tiles with a clear line of sight and the seal breaks and its demon rises, together with weaker escorts from the rank below. Demons are named from the book (Furcas, Andras, Gremory, Paimon, Astaroth, Beelzebub, Lucifer and others). Rank decides the level range, so the strongest demons come last:

| Rank | Levels | Traits |
|---|---|---|
| Knight of Hell | 1-8 | fast claws |
| Marquis of Hell | 9-16 | fire-ball thrower |
| Duke of Hell | 17-24 | winged, tougher |
| Prince of Hell | 25-31 | very tough, faster |
| Lord of Hell | 32-36 | boss-size, crowned in flame |

Seals are decoration only in online play.

![seal](docs/shots/46-demon-seal.jpg)
![demon](docs/shots/47-demon-rises.jpg)

## 5. Weapons (32)

Ammo cost is per shot. Damage is per hit/pellet. Number keys cover the first 9, use Q/E for the rest.

| # | Weapon | Ammo | Type | Notes |
|---|---|---|---|---|
| 0 | Chainsaw | 0 | melee | Free, short range. Stagger-friendly. |
| 1 | Pistol | 1 | hitscan | Accurate, always available. |
| 2 | Shotgun | 2 | 8 pellets | Devastating up close. |
| 3 | Machine gun | 1 | hitscan | Climbing recoil, short bursts. |
| 4 | Bazooka | 3 | rocket | Splash damage. Stay back. |
| 5 | Minigun | 1 | hitscan | Spins up. Heavy ammo drain. |
| 6 | Plasma | 1 | fast bolts | Good vs fast targets. |
| 7 | BFG 9000 | 10 | charged | Hold, then it fires a huge blast. |
| 8 | Grenades | 2 | lobbed | Fuse timer. |
| 9 | AK-47 | 1 | hitscan | Scope available. |
| 10 | Dragunov | 2 | sniper | 140 damage, zoom with B. |
| 11 | PKM | 1 | hitscan | Heavy rapid fire. |
| 12 | Laser rifle | 1 | hitscan | Very accurate. |
| 13 | Room blaster | 25 | huge blast | 600 damage. Panic button. |
| 14 | Hellfire cannon | 1 | fireball | 140 damage. |
| 15 | Doom gatling | 1 | hitscan | 2 shots per tick, 45 damage. |
| 16 | Soul reaper | 1 | 24 pellets | Wide, brutal shotgun. |
| 17 | Armageddon | 1 | bomb | 400 damage. |
| **18** | **Crossbow** | 1 | fast bolt | 70 damage, flies straight and fast. |
| **19** | **Nail gun** | 1 | hitscan, 2 nails | Very fast, cheap, good all-rounder. |
| **20** | **Railgun** | 8 | piercing beam | About 150 damage to **every** enemy in a line, also breaks barrels. |
| **21** | **Arc caster** | 1 | chain lightning | Hits one target then jumps to up to 4 more nearby. |
| **22** | **Sledgehammer** | 0 | melee | 80 damage, free. |
| **23** | **Rocket swarm** | 3 | 3 rockets | Spread of 3, 65 damage each, splash. |
| **24** | **Compound bow** | 1 | fast arrow | 120 damage, almost silent. |
| **25** | **Hunting rifle** | 1 | hitscan | 95 damage, slow, very accurate. |
| **26** | **.44 Magnum** | 1 | hitscan | 60 damage per shot. |
| **27** | **Double barrel** | 3 | 12 pellets | Wide, huge close-range damage. |
| **28** | **Grenade launcher** | 3 | lobbed | 120 splash damage, short fuse. |
| **29** | **Flamethrower** | 0.3 | stream of fire | Cheap, short range, 20 shots a second. |
| **30** | **Tesla gun** | 1 | electric bolt | 38 damage, fast fire. |
| **31** | **Grim scythe** | 0 | melee | 110 damage, free. |

From level 2 onward every floor has one new weapon pickup lying in a room (weapons 18-23 and 24-31 rotate).

| | |
|---|---|
| ![railgun](docs/shots/18-weapon-railgun.jpg) | ![arc caster](docs/shots/18-weapon-arc-caster.jpg) |
| ![rocket swarm](docs/shots/18-weapon-rocket-swarm.jpg) | ![crossbow](docs/shots/18-weapon-crossbow.jpg) |

---

## 6. Spells, melee and vehicles

### Spells (Y to cast, Tab to switch, mana regenerates)
| Spell | Cost | Effect |
|---|---|---|
| **Shock** | 20 | Chain lightning through up to 5 targets, stuns them. |
| **Telekinesis** | 6 | Grab an enemy or barrel, hold it, press again to throw it. Thrown targets damage what they hit. |
| **Freeze** | 25 | Freezes for 6 s (bosses only 1.6 s). Frozen enemies take **2.2x damage**. |
| **Fire** | 22 | Sets targets on fire for 4.5 s. |

Mana regenerates 7/s (4/s on Impossible).

| | |
|---|---|
| ![shock](docs/shots/06-spell-shock.jpg) | ![freeze](docs/shots/06-spell-freeze.jpg) |
| ![fire](docs/shots/06-spell-fire.jpg) | ![telekinesis](docs/shots/06-spell-telekinesis.jpg) |

### Melee (J punch, K kick)
Punches chain: the 4th in a row is an **uppercut** with extra damage and knock-up. Kicks hit harder and stagger. Stone Golems take full damage only when staggered or frozen.

### Motorcycle (M near it)
A bike waits next to your start. It now moves at about twice walking speed with the same instant-feeling steering and wall sliding as the character, so it is easy to control in rooms. Ram monsters for damage, smash barrels. Hard wall hits hurt. The camera switches to third person while riding. Press M to get off.

### Turret (M near it)
Every level has a turret in its biggest side room, surrounded by monsters. While mounted you take half damage. Hold fire, watch the heat bar on the right: at full heat it **overheats** and locks until it cools. Clear the room for +500 score and +30 HP. More waves appear if you linger.

| | |
|---|---|
| ![bike](docs/shots/09-motorcycle.jpg) | ![turret](docs/shots/10-turret.jpg) |

### Third-person view and minimap
`O` shows your character with the weapon over the shoulder. `I` cycles the minimap: it shows walls, doors, keys, stairs, the bike, the turret, enemies, the boss and captives. **Impossible mode disables the map.**

| | |
|---|---|
| ![third person](docs/shots/08-third-person.jpg) | ![big minimap](docs/shots/07-big-minimap.jpg) |

---

## 7. Monsters and bosses

**Regular monsters** (names as shown in the kill feed): Imp, Demon, Trooper, Lost Soul, Gargoyle, Cacodemon, Pumpkin, Baron, Crawler, Shotgunner, Revenant, Runner, Burner, Bomber, Spider, Centipede, Licker, Xenomorph, Insect, Lava Demon, Stag Wendigo, Nurse, Leg Spider, Winged Demon, 88 Gunner, Chainsaw Doll, Flame Doll, Feral Wolf.
**Street monsters** (more common in city levels): **Knife Junkie** is fast and chases you with a kitchen knife. **Gang Zombie** shuffles after you in a bandana and chain and talks ("Eh... what up homie... come here dog...", "You messin' with me, homeboy?"). **Seductresses** are now the same size as the zombies.

![new enemies](docs/shots/25-new-enemies.jpg)

**Newer-Doom-style monsters** unlock as you go deeper:

| Monster | Behavior |
|---|---|
| **Sigil Zealot** | Blinks around the room. |
| **Flayer** | Leaps at you. |
| **Carrion Mancer** | Revives corpses. Kill it first. |
| **Stone Golem** | Armored (takes 22% damage) unless staggered or frozen. |
| **Dreadnought** | Fires rockets. |
| **Swarm Mite** | Comes in groups of 3. Splash weapons shine. |
| **Phantom Stalker** | Fast melee chaser that hits hard (22 damage). |
| **Blood Siren** | Scream hurts and slows. |
| **Jet Imp** | Flying shooter. Aim a little high. |

**Bosses** (one guards every level's exit, scales with level and difficulty, enrages under 35% health):
Grave Warden, Magma Behemoth, Spider Matriarch, Chain Priest, Plague Colossus, Storm Harbinger, Skull Tyrant, Void Empress, and **The Archdemon** (final level). Abilities include charge, ground slam, summon, projectile rings and blink.

![boss](docs/shots/05-boss.jpg)

---

## 7a. Performance, graphics, sound, physics and random attacks

**Best-of-your-hardware quality.** The menu has a **GRAPHICS** row: `AUTO · LOW · MED · HIGH · ULTRA`. AUTO picks a starting tier from the platform (Raspberry Pi, Android or desktop), CPU cores and memory, then a live governor measures real frame time and steps the tier up or down (with hysteresis, so it never flaps). Force one with the `?q=low|med|high|ultra` URL option. Picking a resolution by hand locks resolution; AUTO releases it.

| Tier | Pi render | Android render | Desktop render | Extras |
|---|---|---|---|---|
| LOW | 320x200 | 320x200 | 320x200 | half particles |
| MEDIUM | 320x200 | 640x400 | 640x400 | shadows, vignette, crowd separation, ambience |
| HIGH | 640x400 | 640x400 | 960x600 | + glowing sparks/fire, colour grade, 1x particles |
| ULTRA | 640x400 | 960x600 | 1280x800 | + bloom, 1.3x particles (off in reduce-flashing mode) |

**Graphics:** blob shadows under walkers, additive glow on fire/sparks, vignette, bloom, 1280x800 top resolution. **Sound:** enemy attacks are positional (stereo pan + distance), per-biome ambience beds (desert wind, forest birds, reactor hum and Geiger ticks, city traffic and horns, mall pad, hell drone) and a low-health heartbeat. **Physics:** explosions shove enemies, light props and you; bodies slide and bounce off walls; crowds push apart instead of stacking; debris bounces off walls with livelier rebounds.

**Random attacks.** Every attack is rolled with the JavaScript random function (`Math.random()`, the browser's equivalent of Python's `random.random()`): cooldowns are jittered 55%-150%, melee enemies sometimes lunge or feint a double strike, ranged enemies sometimes fire 3-way fans, spread or strafe, and incoming hits vary from grazes (x0.45) to rare critical hits (x1.6). You get a rare critical too (x1.75). Multiplayer keeps the deterministic patterns.

**Portrait / landscape.** On touch devices the menu has a **SCREEN** row: AUTO (follows how you hold the phone), PORTRAIT or LANDSCAPE. In the Android app it locks the real screen rotation; in a browser it uses fullscreen orientation lock where supported. Press **F8** in game to flip between the two. The touch layout, menus and HUD re-flow automatically (landscape buttons are smaller and translucent on short screens).

![Ultra explosion](docs/shots/48-ultra-explosion.png)
![Graphics menu](docs/shots/49-graphics-menu.png)

## 7c. GTA x DOOM: vehicles, new biomes, enemies, costumes, screensaver

**Smooth movement.** Collision is now circle-vs-tile sliding for you and every enemy. Run diagonally into a wall, a prop or a corner and you glide along it instead of catching.

**Vehicles (press M near one).** Planes, helicopters and cars sit near the start of the AIRPORT, DOCKS and FROZEN WASTES levels, and you can also steal the traffic in DOWNTOWN.
| Vehicle | Controls | Weapons |
|---|---|---|
| Fighter plane | W throttle, S brake, A/D steer, R/F climb or dive, takes off above full-ish speed, M to land and climb out | SPACE twin guns, G bombs (fall and explode), H rockets |
| Helicopter | WASD move, A/D or arrows turn, C up, X down | SPACE minigun, H alternating rockets, G bombs |
| Car | W gas, S brake/reverse, C handbrake drift, G horn, M exit | run enemies over, SPACE drive-by with your normal weapon |
Cockpit overlays show speed, altitude, gun sight and an artificial horizon; the camera rolls in turns (reduced when "reduce flashing" is on). Land before you get out.

**New biomes (9 now).** AIRPORT (hangars, tower, fuel tanks, runway lights, parked planes), DOCKS (container stacks, cranes, warehouses) and FROZEN WASTES (snow pines, ice, cabins, snowmen). Levels 20, 23 and 26 and every ninth after.

**10 new enemies.** Hellhound, Zombie Pilot, Riot Zombie, Suicide Bomber (runs at you and explodes), Frost Yeti, Ice Wraith, Dock Kraken, Sky Gargoyle, Cult Priest (summons hellhounds) and Chainsaw Maniac. They also appear on ordinary levels from level 3 on.

**Costumes.** 8 new suit colours, 8 new hats (top hat, santa, crown, halo, devil horns, viking, pirate, chef) and 10 new outfits (pilot, SWAT, scientist, astronaut, chef, biker, clown, plague doctor, skeleton, mechanic).

**Title screen backgrounds.** BACKGROUND row: fire, city, forest, desert, reactor, space, graveyard, airport, snow, docks, CYCLE (changes every 14 s) or MY IMAGE (upload your own, saved on the device).

**Screensaver.** Press SCREENSAVER > START (or leave the title screen alone for 60 s, switchable) and an AI bot plays through random levels, modes and weapons with unlimited health. Any key, click or touch brings you back to the menu.

![Airport](docs/shots/50-airport.png)
![Fighter plane](docs/shots/51-fighter-plane.png)
![Frozen wastes](docs/shots/52-snow.png)
![New enemies](docs/shots/53-new-enemies.png)
![City title background](docs/shots/54-title-city.png)

## 7b. Halloween in Hell (special release)

Choose **HALLOWEEN IN HELL** in the mode row of the menu, or open `trypicodoom.html?mode=hell`. Red sky, burning halls, zombies hidden inside wall sections that burst out when you pass within about four tiles, and knife nurses in roughly four in ten rooms. Everything else in the game is unchanged. In multiplayer pick HALLOWEEN IN HELL as the room type; the ambushes are seeded from the level so all players see them in the same places. The release page is `halloween/index.html` (published to `/halloween/` by the site workflow).

![Hell start](docs/shots/35-hell-start.jpg) ![Wall zombie](docs/shots/36-hell-wall-burst.jpg) ![Nurse](docs/shots/37-hell-nurse.jpg)

## 8. Items

Health, armor, ammo, keycards, power-ups (rapid fire, double damage, explosive shots), explosive barrels (shoot or telekinesis them), ninja stars, grenades, mines, nukes, fuel and weapon attachments (laser, silencer, grenade launcher, flame). Captives can be rescued. Loot chests sit on top of crate stacks, reachable by ladder or trampoline.

---

## 9. Difficulty

| | Enemy HP | Enemy damage | Enemy speed | Your HP | Ammo | Drops |
|---|---|---|---|---|---|---|
| Easy | 0.6x | 0.5x | 0.8x | 150 | more | more |
| Medium | 1x | 1x | 1x | 100 | normal | normal |
| Hard | 1.6x | 1.6x | 1.2x | 100 | less | less |
| **Impossible** | 4x | 4x | 1.9x | **25** | half | **none** |

Impossible also removes the minimap and cuts mana regeneration. The start message reads "IMPOSSIBLE: NO MAP. NO MERCY."

![impossible](docs/shots/19-impossible-no-map.jpg)

---

## 10. Online play

Open the game from your server link (or set the server in **Advanced**), then:
- **QUICK PLAY**: joins a public co-op room, starts 6 seconds after a second player arrives. Nothing to sign up for.
- **HOST ROOM / JOIN**: private room with a 4-letter code. **COPY INVITE LINK** gives a link that joins by itself.
- **Co-op**: all players must reach the portal. **PvP**: first to the kill goal wins.
- **Smooth connection**: dropped connections reconnect automatically and hold your slot for 25 seconds. Ping is shown on screen. Other players are interpolated so they move smoothly.
- **Leaderboard**: scores post with the name you chose when you finish or die in single player.
- The optional PvP **wager** screen only arranges direct payment between players (the game never touches money). It is hidden in the Android store build.

![online](docs/shots/03-online.jpg)

### Hosting the server for free
See `cloudflare/README.md`: a Cloudflare Worker serves the game, the rooms and the leaderboard, free with no credit card. A Render free option (`server/render.yaml`) and a DigitalOcean / own-computer guide (`deploy/DEPLOY.md`) are also included. On the free Cloudflare plan expect roughly 25 player-hours per day.

---

## 11. Smoothness and comfort

- The game simulates at a fixed 60 steps per second regardless of your screen's refresh rate, so physics and the bike feel the same everywhere.
- Rendering skips redundant work and drops to half-resolution wall columns automatically if frames run slow, then recovers.
- Messages, taunts and cheers are small, and the death-screen insult is small too.

---

## 12. Strategy guide

**General**
1. Use the **big rooms**. Strafe (A/D) constantly. In a large room you can circle most monsters, which they cannot answer.
2. **Freeze then shoot**: freeze does 2.2x damage, so freeze a big target and switch to a slow heavy weapon (Bazooka, Hellfire, Dragunov).
3. **Fire on groups**, **Shock for crowds** (chain stuns up to 5 targets), **Telekinesis** a barrel into a pack.
4. Keep the **Railgun** for lines of enemies down corridors and for bosses (it pierces everything in the line).
5. Spend EP at the **armory** early on armor and ammo. Always keep one grenade or mine for emergencies.
6. Check the **minimap** (I) before opening a door; red dots are enemies, the purple dot is the boss.

**Movement tricks**
- **Trampolines** let you land on crate stacks with loot and get above melee enemies. Land on a crate, snipe, hop down.
- **Slides** are the fastest way down when a boss fight goes wrong. Ladders and stairs are the way back up.
- **Conveyors**: run against the arrows to stay still while you shoot, or let them carry you away from danger.
- The **motorcycle** is strong in the large rooms: ram clusters of weak monsters, but get off before the boss.

**Monster counters**
- Carrion Mancer: kill first (it revives the others).
- Stone Golem: freeze or punch/kick to stagger it, then hit it with heavy damage.
- Swarm Mites: bazooka, rocket swarm or arc caster.
- Dreadnought: stay moving sideways, rockets are slow.
- Blood Siren: close the distance or break line of sight, the scream slows you.

**Bosses**
- They enrage below 35% health. Save your strongest weapon and freeze for that window (bosses are frozen only 1.6 s, so time it for a big hit).
- Keep distance from charge and slam abilities, strafe around projectile rings, kill summoned minions only if they block you.
- The exit stays hidden until the boss is dead.

**Turret room**
- Mount first, then clear. You take half damage while mounted. Short bursts keep heat down. If it overheats, stop firing and let it cool, do not dismount.

**Impossible mode**
- You have 25 HP and enemies hit 4x as hard, and there is no map. Learn each room before entering: peek, shoot, retreat.
- Freeze is your best defense. Fight from doorways. Use corners and crouch (X).
- Rush the turret only if you can take the first room clear; otherwise skip it.

**Multiplayer**
- Co-op: split up the rooms, meet at the portal. Do not rush the boss alone.
- PvP: the third-person view and trampolines make good ambush tools. Shock stuns players too.

---

## 13. Building and publishing

| Task | Where |
|---|---|
| Downloads page and Android build | `.github/workflows/firmware.yml` (run it, then open your GitHub Pages link) |
| Android project and Play Store notes | `android/README.md`, `store/` |
| Free multiplayer server | `cloudflare/README.md` and `.github/workflows/cloudflare.yml` |
| Other servers | `server/` (Node, zero dependencies), `deploy/DEPLOY.md` |
| Pi kiosk | `ports/pi/pi-kiosk.sh` |
| Desktop launchers | `ports/desktop/` |

The game source is the single file `server/public/index.html` (copies in `trypicodoom_v2.html`, `cloudflare/public/` and the Android assets).

**Android store build**: the Cash App wager section is hidden. Set `MP_DEFAULT` in the game file to your server host so Quick Play works with no typing.

### Legacy
The earlier PicoSystem / Cardputer / ESP32 builds and the C++ engine (`main.cpp`) are kept under `ports/` and described in `docs/LEGACY-PICOSYSTEM.md`. They did not get the newest features.

---

## 14. Troubleshooting

| Problem | Fix |
|---|---|
| No sound | Click or press a key first. Browsers block audio until you interact. |
| Online says "can't reach the server" | Open the game from your server link, or open **Advanced** and type your server address (no `https://`). The in-chat preview blocks online play. |
| Choppy on a Pi 4 | Close other apps. The game lowers resolution on its own. |
| Flashing still bothers you | Reload and make sure **Reduce flashing effects** is ticked. Lower screen brightness and play in a lit room. |
| Getting caught on walls or crates | Fixed: movement now slides along edges and pushes you out if you are wedged. If you still find a spot, report the level number. |
| Stuck in an elevator or armory menu | Press **Esc** or use the STAY HERE / close button. |
| Android install blocked | Allow "install unknown apps" for your browser, or use the Play Store build. |

Not tested here: audio, real Android devices, a real Pi, and the Cloudflare deployment (no access from the build environment). The first run on your hardware is the real test; send me anything that misbehaves.

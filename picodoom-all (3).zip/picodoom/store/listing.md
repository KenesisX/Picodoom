# Google Play listing (copy/paste)

**App name (max 30):** Try Pico Doom  *(see policy-notes.md - "Doom" is someone else's trademark; consider a different name)*
**Short description (max 80):** Retro raycast demon shooter: 27 hellish levels, 14+ weapons, stairs & elevators.

**Full description (max 4000):**
Fight through 27 hellish levels in a fast retro first-person shooter built from scratch.

* 14 weapons - chainsaw, shotgun, minigun, plasma, BFG, bazooka, AK-47, Dragunov sniper, laser rifle and a room-clearing blaster
* Dozens of demons, zombies, AK-wielding undead and bosses
* Levels with 1-4 floors, staircases, elevators, escalators, ladders and crates to climb
* Hazards: lava, acid, bounce pads, portals, explosive barrels, tesla coils, armable bombs and mines
* Armory boxes - spend evil points on attachments, grenades, nukes and more
* Pick your look: soldier, ninja, gangster, police, firefighter and more, with hats and masks
* 57+ procedurally generated soundtracks, or upload your own music
* Pulsing colored lights, gore, and a very mean announcer
* Optional online co-op and player-vs-player (2-4 players)
* Share your stats and find out which animal you are

Mature content: violence, gore, crude humor and horror themes.

**Category:** Games > Action   **Tags:** shooter, retro, horror
**Contact email:** (yours)   **Privacy policy URL:** host store/privacy-policy.html (GitHub Pages works)
**Graphics:** icon-512.png, feature-graphic-1024x500.png, screenshots/ (1920x1080, landscape)

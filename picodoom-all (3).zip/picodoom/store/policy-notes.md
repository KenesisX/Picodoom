# Read before you submit - things Google Play may reject or restrict

I can't predict a review, but these are the real risks in the current game:

1. **Name / trademark.** "Doom" is a registered trademark (id Software / ZeniMax). A title containing it, plus Doom-style
   demons and weapon looks, risks an *impersonation / intellectual-property* rejection or takedown. Strongly consider renaming
   (e.g. "Try Pico Hell") and keeping the art original. Selling it makes this riskier, not safer.
2. **Real-money wagering.** The Cash App betting feature is hidden in the Android build (`assets/index.html`). Keep it off:
   real-money gambling in apps needs licences and Google approval. Do not re-enable it for Play.
3. **Drugs.** Coke / meth / acid / smack bags that give power-ups, plus smoking sounds, can be read as *promoting illegal
   drug use* (Inappropriate Content). Safest fix: re-skin them as made-up power-ups ("Turbo", "Warp"...). I can build a
   "Play-safe skin" for you - ask.
4. **Sexual content.** Stripper outfits, flirty announcer girls and the SEXY cheat lines are suggestive but not nudity.
   Suggestive content needs an appropriate (Mature) rating; anything resembling sexual solicitation (the seductress enemy) is a risk.
   Profanity in the SEXY cheat lines will push the rating up.
5. **Content rating.** Complete the IARC questionnaire honestly (violence/gore, profanity, drug references, suggestive themes).
   Expect Mature 17+ / PEGI 18. Don't target children; mark the target audience 18+ (not "Designed for Families").
6. **Account rules.** A *personal* developer account created after Nov 2023 must run a closed test with 12+ testers for 14 days
   before production access. Organisation accounts (Strikeback Tech LLC with a D-U-N-S number) skip that.
   One-time $25 fee. To charge for the app / sell items you also need a Google payments (merchant) profile.
7. **Target API level.** Google raises the minimum yearly. This project targets API 36 (current as of this build) - re-check the
   Play Console message before each release.
8. **Data safety form.** Offline play collects nothing. Online multiplayer sends your chosen display name + position to the
   server you type in (not stored by this app). Answer "data shared: none; collected: none" only if you run the relay without logging;
   otherwise declare "name" (not linked to identity). Link the privacy policy.


## v2 content notes
- New content: bosses, fantasy-violence spells, punch/kick, motorcycle, turret. Same cartoon-gore level as before; answer the IARC questionnaire honestly (fantasy violence, blood).
- Leaderboard sends name + score only when a server is configured (disclosed in the privacy policy).
- Wager UI stays hidden (`display:none`) in the store build.

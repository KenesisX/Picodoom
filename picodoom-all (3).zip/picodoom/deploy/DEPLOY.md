# Hosting the multiplayer server

**Recommended free option: Cloudflare Workers (no credit card).** See `../cloudflare/README.md`.
Other free option: Render free web service (`../server/render.yaml`), which sleeps after 15 idle minutes and takes about a minute to wake (the game reconnects by itself).
Paid / full control: DigitalOcean (below), or your own computer with a Cloudflare Tunnel.

---

# Hosting Try Pico Doom online (DigitalOcean, or your own PC)

The server is one Node file with **no dependencies**. It serves the game and runs multiplayer. Players just open the link,
type a name and tap **QUICK PLAY** - no accounts. If someone's connection drops they have 25 s to come back into their slot.

## Option A - DigitalOcean App Platform (easiest, ~$5/month)
1. Put this folder on GitHub (private is fine).
2. Edit `.do/app.yaml` -> set `repo: YOUR_GITHUB_USER/picodoom`.
3. DigitalOcean dashboard -> **Create -> App Platform** -> choose the repo. It reads `.do/app.yaml`. (Or `doctl apps create --spec .do/app.yaml`.)
4. You get `https://trypicodoom-xxxxx.ondigitalocean.app`. Open it = the game. WebSockets work out of the box, HTTPS included.
5. Android app / local file: set `MP_DEFAULT` near the end of the game's script to `trypicodoom-xxxxx.ondigitalocean.app`
   (or players type it once under PLAY ONLINE -> ADVANCED).
Note: App Platform's disk resets on each deploy, so the **leaderboard** is wiped then. Everything else is unaffected.

## Option B - DigitalOcean Droplet (keeps the leaderboard, ~$6/month, best latency control)
1. Create an Ubuntu droplet (smallest size is fine), SSH in as root.
2. `curl -fsSL https://raw.githubusercontent.com/YOUR_GITHUB_USER/picodoom/main/deploy/droplet-setup.sh | bash`
   Add `DOMAIN=play.yourdomain.com` before `bash` if you have a domain; otherwise you get a free HTTPS name like `203-0-113-7.sslip.io`.
3. It installs Docker, builds the server, gets an HTTPS certificate automatically (Caddy) and opens only ports 22/80/443.
Update later: `cd /opt/picodoom && git pull && cd deploy && docker compose up -d --build`.
Pick the droplet region nearest your players: the lowest ping matters more than anything else for "smooth".

## Option C - run it from your own computer
* Just run it: `cd server && node server.js` -> `http://YOUR-LAN-IP:8080` for friends on the same Wi-Fi.
* Over the internet **without opening router ports**: use a tunnel (third party, free): install `cloudflared`, run
  `cloudflared tunnel --url http://localhost:8080` and share the `https://*.trycloudflare.com` link it prints. (Tailscale Funnel works too.)
  Your PC must stay on and the link changes each run unless you set up a named tunnel.

## Settings
`PORT` (default 8080) - `DATA_DIR` (leaderboard file folder). Health check: `/health`. Leaderboard: `/api/top`.

## Cost / ops notes
One small instance comfortably serves dozens of simultaneous rooms (each player sends ~20 tiny messages/s).
A 4-player room is about 3 KB/s per player. Nothing is stored except the optional leaderboard (name + score).

#!/usr/bin/env bash
# One-shot setup for a fresh DigitalOcean Droplet (Ubuntu 22.04/24.04, the $6/mo size is plenty).
# Run as root on the droplet:   curl -fsSL <raw url of this file> | DOMAIN=play.example.com bash
# No domain? Leave DOMAIN empty and you get a free HTTPS name like 203-0-113-7.sslip.io
set -euo pipefail
apt-get update -y && apt-get install -y ca-certificates curl git ufw
command -v docker >/dev/null || curl -fsSL https://get.docker.com | sh
IP=$(curl -fsS https://api.ipify.org)
export DOMAIN="${DOMAIN:-${IP//./-}.sslip.io}"
[ -d /opt/picodoom ] || git clone "${REPO:-https://github.com/YOUR_GITHUB_USER/picodoom.git}" /opt/picodoom
cd /opt/picodoom/deploy && git -C /opt/picodoom pull --ff-only || true
echo "DOMAIN=$DOMAIN" > .env
docker compose up -d --build
ufw allow OpenSSH >/dev/null; ufw allow 80,443/tcp >/dev/null; ufw --force enable >/dev/null
echo; echo "DONE. Play at:  https://$DOMAIN    (server address for the Android app: $DOMAIN)"

// Try Pico Doom multiplayer server v2. Zero dependencies (Node 18+).
// Serves the web game and relays WebSocket rooms (2-4 players): co-op and PvP.
//  - Guest sessions: no accounts. A random token lets a dropped player RESUME their slot for 25 s.
//  - Quick Play: one tap joins (or creates) a public co-op room, auto-starts when 2+ players are in.
//  - Batched 20 Hz position updates, ping/pong latency, keep-alive pings (cloud load balancers drop idle sockets).
//  - Tiny global leaderboard: GET /api/top, POST /api/score (stored in DATA_DIR/scores.json).
// Wagers are NON-CUSTODIAL: the server only does arithmetic and tells losers who to pay; it never touches money.
const http = require('http'), crypto = require('crypto'), fs = require('fs'), path = require('path'), zlib = require('zlib');
const PORT = process.env.PORT || 8080, MAXP = 4, GOALS = [5, 10, 15, 20, 25, 50, 100], GRACE = 25000, TICK = 50;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const rooms = new Map(), gone = new Map(); let nextId = 1;
const clean = (s, n, re) => String(s || '').replace(re || /[^\w $.-]/g, '').slice(0, n);
const money = v => Math.max(0, Math.min(1000, Math.round(+v || 0)));
const frame = str => { const b = Buffer.from(str), l = b.length; let h;
  if (l < 126) h = Buffer.from([0x81, l]); else if (l < 65536) { h = Buffer.alloc(4); h[0] = 0x81; h[1] = 126; h.writeUInt16BE(l, 2); }
  else { h = Buffer.alloc(10); h[0] = 0x81; h[1] = 127; h.writeBigUInt64BE(BigInt(l), 2); } return Buffer.concat([h, b]); };
const raw = (q, buf) => { if (q.s && !q.s.destroyed) q.s.write(buf); };
const send = (q, o) => raw(q, frame(JSON.stringify(o)));
const bc = (r, o, except) => { const f = frame(JSON.stringify(o)); for (const q of r.p.values()) if (q !== except) raw(q, f); };

function parse(q, chunk, onmsg) {
  q.buf = Buffer.concat([q.buf, chunk]); q.alive = Date.now();
  for (;;) { const b = q.buf; if (b.length < 2) return; let len = b[1] & 127, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; } else if (len === 127) { q.s.destroy(); return; }
    const masked = b[1] & 128; if (masked) off += 4; if (len > 8192) { q.s.destroy(); return; } if (b.length < off + len) return;
    let d = b.subarray(off, off + len); if (masked) { const k = b.subarray(off - 4, off); d = Buffer.from(d.map((v, i) => v ^ k[i & 3])); }
    q.buf = b.subarray(off + len); const op = b[0] & 15;
    if (op === 8) { q.s.end(); return; } if (op === 9) { q.s.write(Buffer.from([0x8a, 0])); continue; } if (op === 10) continue; if (op === 1) onmsg(d.toString()); } }

const lobby = (r, q) => ({ t: 'lobby', room: r.code, you: q.id, host: r.host, mode: r.mode, pvp: r.mode === 'pvp' ? 1 : 0, goal: r.goal, hal: r.hal, entry: r.entry, n: r.p.size, quick: r.quick ? 1 : 0,
  players: [...r.p.values()].map(x => ({ id: x.id, slot: x.slot, name: x.name, tag: x.tag, extra: x.extra })) });
const board = r => [...r.p.values()].map(x => ({ id: x.id, slot: x.slot, name: x.name, k: x.k }));
function scores(r) { for (const q of r.p.values()) send(q, { t: 'sc', list: board(r), mine: q.k, goal: r.goal }); }
function win(r, w) { r.over = true; r.started = false;
  const stake = q => r.entry + q.extra, pot = [...r.p.values()].reduce((a, q) => a + stake(q), 0);
  for (const q of r.p.values()) send(q, { t: 'win', w: w.id, name: w.name, payto: w.tag, pot, owe: q === w ? 0 : stake(q), board: board(r), you: q.id }); }
function startRoom(r) { if (r.started) return; r.started = true; r.over = false; r.cdT = null; for (const x of r.p.values()) { x.k = 0; x.exited = false; }
  bc(r, { t: 'start', mode: r.mode, pvp: r.mode === 'pvp' ? 1 : 0, goal: r.goal, hal: r.hal }); scores(r); }
function drop(q) { const r = q.room; if (!r) return; r.p.delete(q.id); gone.delete(q.tok); r.pend && r.pend.delete(q.id); bc(r, { t: 'left', id: q.id, slot: q.slot }); q.room = null;
  if (!r.p.size) { rooms.delete(r.code); return; } if (r.host === q.id) r.host = r.p.values().next().value.id;
  if (!r.started) { [...r.p.values()].forEach(x => send(x, lobby(r, x))); if (r.quick && r.p.size < 2) r.cdT = null; } }
function leave(q, bye) { const r = q.room; if (!r) return;
  if (!bye && r.started && !r.over && r.p.size > 1) { q.gone = Date.now(); gone.set(q.tok, q); bc(r, { t: 'away', id: q.id }, q); return; } drop(q); }
function joinRoom(q, r, m) { const used = new Set([...r.p.values()].map(x => x.slot)); q.slot = [0, 1, 2, 3].find(i => !used.has(i));
  Object.assign(q, { room: r, name: clean(m.name, 10) || 'PLAYER', tag: clean(m.tag, 20, /[^\w$]/g).replace('$', ''), extra: money(m.extra), k: 0, exited: false });
  r.p.set(q.id, q); for (const x of r.p.values()) send(x, lobby(r, x));
  if (r.quick && r.p.size >= 2 && !r.started && !r.cdT) { r.cdT = Date.now() + 6000; bc(r, { t: 'cd', s: 6 }); } }
function newRoom(q, m, quick) { let code; do code = Math.random().toString(36).slice(2, 6).toUpperCase(); while (rooms.has(code));
  const r = { code, mode: m.mode === 'pvp' && !quick ? 'pvp' : 'coop', goal: GOALS.includes(+m.goal) ? +m.goal : 10, hal: +m.hal === 2 ? 2 : (m.hal ? 1 : 0), entry: quick ? 0 : money(m.entry), p: new Map(), pend: new Map(), host: q.id, started: false, quick: !!quick };
  rooms.set(code, r); return r; }

function handle(q, m) {
  if (m.t === 'p') return send(q, { t: 'pg', c: m.c, n: rooms.size });
  if (m.t === 'resume') { const o = gone.get(clean(m.tok, 40, /[^\w]/g)); if (!o || !o.room || Date.now() - o.gone > GRACE) return send(q, { t: 'noresume' });
    gone.delete(o.tok); const r = o.room; r.p.set(o.id, q); Object.assign(q, { id: o.id, tok: o.tok, room: r, slot: o.slot, name: o.name, tag: o.tag, extra: o.extra, k: o.k, exited: o.exited, gone: 0 }); o.room = null;
    send(q, { t: 'resumed' }); send(q, lobby(r, q)); if (r.started) send(q, { t: 'start', mode: r.mode, pvp: r.mode === 'pvp' ? 1 : 0, goal: r.goal, hal: r.hal, resume: 1 }); scores(r); bc(r, { t: 'back', id: q.id }, q); return; }
  if (m.t === 'join' || m.t === 'quick') {
    if (q.room) return; let r;
    if (m.t === 'quick') { r = [...rooms.values()].find(x => x.quick && !x.started && x.p.size < MAXP) || newRoom(q, m, true); }
    else if (m.host) r = newRoom(q, m, false);
    else { r = rooms.get(clean(m.room, 4, /[^A-Za-z0-9]/g).toUpperCase());
      if (!r) return send(q, { t: 'err', m: 'ROOM NOT FOUND' }); if (r.started) return send(q, { t: 'err', m: 'GAME ALREADY STARTED' }); if (r.p.size >= MAXP) return send(q, { t: 'err', m: 'ROOM FULL (4 MAX)' }); }
    return joinRoom(q, r, m); }
  if (m.t === 'bye') return leave(q, true);
  const r = q.room; if (!r) return;
  switch (m.t) {
    case 'start': if (r.host !== q.id || r.p.size < 2 && !r.solo) { if (r.host === q.id) r.solo = 1; else return; } startRoom(r); break;
    case 's': r.pend.set(q.id, { id: q.id, slot: q.slot, name: q.name, x: m.x, y: m.y, a: m.a, hp: m.hp }); break;
    case 'm': bc(r, { t: 'm', i: m.i, d: m.d }, q); break;
    case 'hit': if (r.mode === 'pvp') { const to = r.p.get(m.to); if (to && to !== q) send(to, { t: 'hit', from: q.id, d: Math.min(200, Math.max(0, +m.d || 0)) }); } break;
    case 'killed': case 'k': { if (r.mode !== 'pvp' || !r.started || r.over) break;
      const by = m.t === 'k' ? q : r.p.get(m.by); if (!by || (m.t === 'killed' && by === q)) break;
      by.k++; scores(r); if (by.k >= r.goal) win(r, by); break; }
    case 'exit': if (r.mode !== 'coop' || !r.started) break; q.exited = true;
      { const n = [...r.p.values()].filter(x => x.exited).length; for (const x of r.p.values()) send(x, { t: 'exitn', n, total: r.p.size });
        if (n === r.p.size) { for (const x of r.p.values()) x.exited = false; for (const x of r.p.values()) send(x, { t: 'done' }); } } break;
  } }

// 20 Hz batched position broadcast + quick-play countdown + dead-socket reaper
setInterval(() => { const now = Date.now();
  for (const r of rooms.values()) {
    if (r.pend.size) { const f = frame(JSON.stringify({ t: 'st', p: [...r.pend.values()] })); r.pend.clear(); for (const q of r.p.values()) raw(q, f); }
    if (r.cdT && now >= r.cdT) startRoom(r); } }, TICK);
setInterval(() => { const now = Date.now();
  for (const [, q] of gone) if (now - q.gone > GRACE) drop(q);
  for (const r of rooms.values()) for (const q of r.p.values()) { if (q.s && !q.s.destroyed) { if (now - q.alive > 60000) q.s.destroy(); else q.s.write(Buffer.from([0x89, 0])); } } }, 20000);

// ---- leaderboard ----
let top = []; const TOPF = path.join(DATA_DIR, 'scores.json');
try { top = JSON.parse(fs.readFileSync(TOPF, 'utf8')); } catch (e) {}
let dirty = false; setInterval(() => { if (!dirty) return; dirty = false; try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(TOPF, JSON.stringify(top)); } catch (e) {} }, 15000);
const rl = new Map();
function api(req, res) {
  const h = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type', 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
  if (req.method === 'OPTIONS') { res.writeHead(204, h); return res.end(); }
  if (req.url.startsWith('/api/top')) { res.writeHead(200, h); return res.end(JSON.stringify(top.slice(0, 20))); }
  if (req.url.startsWith('/api/score') && req.method === 'POST') { const ip = req.socket.remoteAddress, now = Date.now(); if ((rl.get(ip) || 0) > now - 3000) { res.writeHead(429, h); return res.end('{}'); } rl.set(ip, now);
    let b = ''; req.on('data', c => { b += c; if (b.length > 1024) req.destroy(); }); req.on('end', () => { try { const m = JSON.parse(b), s = Math.max(0, Math.min(1e9, +m.score | 0));
      if (s > 0) { top.push({ name: clean(m.name, 10) || 'PLAYER', score: s, lvl: Math.max(1, Math.min(36, +m.lvl | 0)), d: ['EASY', 'MEDIUM', 'HARD', 'IMPOSSIBLE'][+m.diff | 0] || 'MEDIUM', t: Date.now() }); top.sort((a, c) => c.score - a.score); top = top.slice(0, 100); dirty = true; }
      res.writeHead(200, h); res.end('{"ok":1}'); } catch (e) { res.writeHead(400, h); res.end('{}'); } }); return; }
  res.writeHead(404, h); res.end('{}'); }

// ---- static (gzip cached) ----
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.png': 'image/png', '.json': 'application/json' }, cache = new Map();
function serve(req, res) { const u = req.url.split('?')[0], f = path.join(__dirname, 'public', u === '/' ? 'index.html' : path.normalize(u).replace(/^(\.\.[\/\\])+/, ''));
  let c = cache.get(f); const ok = () => { const gz = /gzip/.test(req.headers['accept-encoding'] || '') && c.gz; const hd = { 'Content-Type': mime[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'public, max-age=300' }; if (gz) hd['Content-Encoding'] = 'gzip'; res.writeHead(200, hd); res.end(gz ? c.gz : c.raw); };
  if (c) return ok();
  fs.readFile(f, (e, d) => { if (e) { res.statusCode = 404; return res.end('not found'); } c = { raw: d, gz: /\.(html|js|json)$/.test(f) ? zlib.gzipSync(d, { level: 9 }) : null }; cache.set(f, c); ok(); }); }
const server = http.createServer((req, res) => { if (req.url === '/health') { res.end('ok'); return; } if (req.url.startsWith('/api/')) return api(req, res); serve(req, res); });
server.on('upgrade', (req, s) => {
  const key = req.headers['sec-websocket-key']; if (!key) return s.destroy();
  s.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' +
    crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64') + '\r\n\r\n');
  const q = { id: nextId++, s, buf: Buffer.alloc(0), room: null, n: 0, t0: Date.now(), alive: Date.now(), tok: crypto.randomBytes(12).toString('hex') }; s.setNoDelay(true);
  send(q, { t: 'hi', tok: q.tok, id: q.id });
  s.on('data', c => parse(q, c, txt => { if (Date.now() - q.t0 > 1000) { q.t0 = Date.now(); q.n = 0; } if (++q.n > 150) return; let m; try { m = JSON.parse(txt); } catch (e) { return; } if (m && typeof m === 'object') handle(q, m); }));
  s.on('close', () => leave(q)); s.on('error', () => s.destroy()); });
server.listen(PORT, () => console.log('Try Pico Doom server v2 on :' + PORT));

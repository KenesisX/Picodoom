// Try Pico Doom multiplayer on Cloudflare Workers (free plan, no credit card).
// One Worker serves the game (static assets), the WebSocket rooms (/ws) and the leaderboard (/api/*).
// All rooms live in one Durable Object ("Hub"), which is plenty for a few hundred players.
// Same protocol as server/server.js, so the game works unchanged with either.
const MAXP = 4, GOALS = [5, 10, 15, 20, 25, 50, 100], GRACE = 25000, TICK = 50;
const clean = (s, n, re) => String(s || '').replace(re || /[^\w $.-]/g, '').slice(0, n);
const money = v => Math.max(0, Math.min(1000, Math.round(+v || 0)));
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type', 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };

export default {
  async fetch(req, env) {
    const u = new URL(req.url);
    if (u.pathname === '/health') return new Response('ok');
    if (u.pathname === '/ws' || u.pathname.startsWith('/api/')) return env.HUB.get(env.HUB.idFromName('main')).fetch(req);
    return env.ASSETS.fetch(req);
  }
};

export class Hub {
  constructor(state) {
    this.state = state; this.rooms = new Map(); this.gone = new Map(); this.nextId = 1; this.top = []; this.rl = new Map(); this.timers = null; this.socks = new Set();
    state.blockConcurrencyWhile(async () => { this.top = (await state.storage.get('top')) || []; });
  }
  send(q, o) { try { q.s.send(JSON.stringify(o)); } catch (e) {} }
  raw(q, str) { try { q.s.send(str); } catch (e) {} }
  bc(r, o, except) { const f = JSON.stringify(o); for (const q of r.p.values()) if (q !== except) this.raw(q, f); }

  async fetch(req) {
    const u = new URL(req.url);
    if (u.pathname === '/ws') {
      if (req.headers.get('Upgrade') !== 'websocket') return new Response('expected websocket', { status: 426 });
      const pair = new WebSocketPair(), [client, server] = Object.values(pair); server.accept(); this.attach(server); this.ensureTimers();
      return new Response(null, { status: 101, webSocket: client });
    }
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    if (u.pathname === '/api/top') return new Response(JSON.stringify(this.top.slice(0, 20)), { headers: CORS });
    if (u.pathname === '/api/score' && req.method === 'POST') {
      const ip = req.headers.get('CF-Connecting-IP') || 'x', now = Date.now();
      if ((this.rl.get(ip) || 0) > now - 3000) return new Response('{}', { status: 429, headers: CORS }); this.rl.set(ip, now);
      try { const m = JSON.parse((await req.text()).slice(0, 1024)), s = Math.max(0, Math.min(1e9, +m.score | 0));
        if (s > 0) { this.top.push({ name: clean(m.name, 10) || 'PLAYER', score: s, lvl: Math.max(1, Math.min(36, +m.lvl | 0)), d: ['EASY', 'MEDIUM', 'HARD', 'IMPOSSIBLE'][+m.diff | 0] || 'MEDIUM', t: now });
          this.top.sort((a, c) => c.score - a.score); this.top = this.top.slice(0, 100); await this.state.storage.put('top', this.top); }
        return new Response('{"ok":1}', { headers: CORS }); } catch (e) { return new Response('{}', { status: 400, headers: CORS }); }
    }
    return new Response('{}', { status: 404, headers: CORS });
  }

  attach(ws) {
    const q = { id: this.nextId++, s: ws, room: null, n: 0, t0: Date.now(), alive: Date.now(), tok: [...crypto.getRandomValues(new Uint8Array(12))].map(b => b.toString(16).padStart(2, '0')).join('') };
    this.socks.add(q); this.send(q, { t: 'hi', tok: q.tok, id: q.id });
    ws.addEventListener('message', ev => { q.alive = Date.now(); if (typeof ev.data !== 'string' || ev.data.length > 8192) return;
      if (Date.now() - q.t0 > 1000) { q.t0 = Date.now(); q.n = 0; } if (++q.n > 150) return; let m; try { m = JSON.parse(ev.data); } catch (e) { return; } if (m && typeof m === 'object') this.handle(q, m); });
    const end = () => { this.socks.delete(q); q.dead = true; this.leave(q); };
    ws.addEventListener('close', end); ws.addEventListener('error', end);
  }
  ensureTimers() {
    if (this.timers) return;
    this.timers = [setInterval(() => { const now = Date.now();
      for (const r of this.rooms.values()) {
        if (r.pend.size) { const f = JSON.stringify({ t: 'st', p: [...r.pend.values()] }); r.pend.clear(); for (const q of r.p.values()) this.raw(q, f); }
        if (r.cdT && now >= r.cdT) this.startRoom(r); } }, TICK),
      setInterval(() => { const now = Date.now();
        for (const [, q] of this.gone) if (now - q.gone > GRACE) this.drop(q);
        for (const q of this.socks) if (now - q.alive > 60000) { try { q.s.close(); } catch (e) {} } }, 20000)];
  }

  lobby(r, q) { return { t: 'lobby', room: r.code, you: q.id, host: r.host, mode: r.mode, pvp: r.mode === 'pvp' ? 1 : 0, goal: r.goal, hal: r.hal, entry: r.entry, n: r.p.size, quick: r.quick ? 1 : 0,
    players: [...r.p.values()].map(x => ({ id: x.id, slot: x.slot, name: x.name, tag: x.tag, extra: x.extra })) }; }
  board(r) { return [...r.p.values()].map(x => ({ id: x.id, slot: x.slot, name: x.name, k: x.k })); }
  scores(r) { for (const q of r.p.values()) this.send(q, { t: 'sc', list: this.board(r), mine: q.k, goal: r.goal }); }
  win(r, w) { r.over = true; r.started = false; const stake = q => r.entry + q.extra, pot = [...r.p.values()].reduce((a, q) => a + stake(q), 0);
    for (const q of r.p.values()) this.send(q, { t: 'win', w: w.id, name: w.name, payto: w.tag, pot, owe: q === w ? 0 : stake(q), board: this.board(r), you: q.id }); }
  startRoom(r) { if (r.started) return; r.started = true; r.over = false; r.cdT = null; for (const x of r.p.values()) { x.k = 0; x.exited = false; }
    this.bc(r, { t: 'start', mode: r.mode, pvp: r.mode === 'pvp' ? 1 : 0, goal: r.goal, hal: r.hal }); this.scores(r); }
  drop(q) { const r = q.room; if (!r) return; r.p.delete(q.id); this.gone.delete(q.tok); r.pend && r.pend.delete(q.id); this.bc(r, { t: 'left', id: q.id, slot: q.slot }); q.room = null;
    if (!r.p.size) { this.rooms.delete(r.code); return; } if (r.host === q.id) r.host = r.p.values().next().value.id;
    if (!r.started) { [...r.p.values()].forEach(x => this.send(x, this.lobby(r, x))); if (r.quick && r.p.size < 2) r.cdT = null; } }
  leave(q, bye) { const r = q.room; if (!r) return;
    if (!bye && r.started && !r.over && r.p.size > 1) { q.gone = Date.now(); this.gone.set(q.tok, q); this.bc(r, { t: 'away', id: q.id }, q); return; } this.drop(q); }
  joinRoom(q, r, m) { const used = new Set([...r.p.values()].map(x => x.slot)); q.slot = [0, 1, 2, 3].find(i => !used.has(i));
    Object.assign(q, { room: r, name: clean(m.name, 10) || 'PLAYER', tag: clean(m.tag, 20, /[^\w$]/g).replace('$', ''), extra: money(m.extra), k: 0, exited: false });
    r.p.set(q.id, q); for (const x of r.p.values()) this.send(x, this.lobby(r, x));
    if (r.quick && r.p.size >= 2 && !r.started && !r.cdT) { r.cdT = Date.now() + 6000; this.bc(r, { t: 'cd', s: 6 }); } }
  newRoom(q, m, quick) { let code; do code = Math.random().toString(36).slice(2, 6).toUpperCase(); while (this.rooms.has(code));
    const r = { code, mode: m.mode === 'pvp' && !quick ? 'pvp' : 'coop', goal: GOALS.includes(+m.goal) ? +m.goal : 10, hal: +m.hal === 2 ? 2 : (m.hal ? 1 : 0), entry: quick ? 0 : money(m.entry), p: new Map(), pend: new Map(), host: q.id, started: false, quick: !!quick };
    this.rooms.set(code, r); return r; }

  handle(q, m) {
    if (m.t === 'p') return this.send(q, { t: 'pg', c: m.c, n: this.rooms.size });
    if (m.t === 'resume') { const o = this.gone.get(clean(m.tok, 40, /[^\w]/g)); if (!o || !o.room || Date.now() - o.gone > GRACE) return this.send(q, { t: 'noresume' });
      this.gone.delete(o.tok); const r = o.room; r.p.set(o.id, q); Object.assign(q, { id: o.id, tok: o.tok, room: r, slot: o.slot, name: o.name, tag: o.tag, extra: o.extra, k: o.k, exited: o.exited, gone: 0 }); o.room = null;
      this.send(q, { t: 'resumed' }); this.send(q, this.lobby(r, q)); if (r.started) this.send(q, { t: 'start', mode: r.mode, pvp: r.mode === 'pvp' ? 1 : 0, goal: r.goal, hal: r.hal, resume: 1 }); this.scores(r); this.bc(r, { t: 'back', id: q.id }, q); return; }
    if (m.t === 'join' || m.t === 'quick') {
      if (q.room) return; let r;
      if (m.t === 'quick') { r = [...this.rooms.values()].find(x => x.quick && !x.started && x.p.size < MAXP) || this.newRoom(q, m, true); }
      else if (m.host) r = this.newRoom(q, m, false);
      else { r = this.rooms.get(clean(m.room, 4, /[^A-Za-z0-9]/g).toUpperCase());
        if (!r) return this.send(q, { t: 'err', m: 'ROOM NOT FOUND' }); if (r.started) return this.send(q, { t: 'err', m: 'GAME ALREADY STARTED' }); if (r.p.size >= MAXP) return this.send(q, { t: 'err', m: 'ROOM FULL (4 MAX)' }); }
      return this.joinRoom(q, r, m); }
    if (m.t === 'bye') return this.leave(q, true);
    const r = q.room; if (!r) return;
    switch (m.t) {
      case 'start': if (r.host !== q.id || r.p.size < 2 && !r.solo) { if (r.host === q.id) r.solo = 1; else return; } this.startRoom(r); break;
      case 's': r.pend.set(q.id, { id: q.id, slot: q.slot, name: q.name, x: m.x, y: m.y, a: m.a, hp: m.hp }); break;
      case 'm': this.bc(r, { t: 'm', i: m.i, d: m.d }, q); break;
      case 'hit': if (r.mode === 'pvp') { const to = r.p.get(m.to); if (to && to !== q) this.send(to, { t: 'hit', from: q.id, d: Math.min(200, Math.max(0, +m.d || 0)) }); } break;
      case 'killed': case 'k': { if (r.mode !== 'pvp' || !r.started || r.over) break;
        const by = m.t === 'k' ? q : r.p.get(m.by); if (!by || (m.t === 'killed' && by === q)) break;
        by.k++; this.scores(r); if (by.k >= r.goal) this.win(r, by); break; }
      case 'exit': if (r.mode !== 'coop' || !r.started) break; q.exited = true;
        { const n = [...r.p.values()].filter(x => x.exited).length; for (const x of r.p.values()) this.send(x, { t: 'exitn', n, total: r.p.size });
          if (n === r.p.size) { for (const x of r.p.values()) x.exited = false; for (const x of r.p.values()) this.send(x, { t: 'done' }); } } break;
    } }
}

# Free multiplayer server on Cloudflare (no credit card)

One Worker serves the game, the multiplayer rooms (WebSocket `/ws`) and the leaderboard (`/api/top`, `/api/score`).

## Deploy in 5 minutes
1. Make a free account at dash.cloudflare.com (email only).
2. On your computer (Node 18+): 
   ```
   cd cloudflare
   cp ../server/public/index.html public/index.html
   npx wrangler login
   npx wrangler deploy
   ```
3. Wrangler prints your address, like `trypicodoom.YOURNAME.workers.dev`. Open it: that is the game with online play built in.
4. Android / saved copies: put that host in `MP_DEFAULT` (search the game file for `MP_DEFAULT`), e.g. `const MP_DEFAULT='trypicodoom.yourname.workers.dev'`.

Or let GitHub do it: add secrets `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`, run **Deploy multiplayer to Cloudflare**.

## Free-plan budget (Cloudflare Durable Objects, resets 00:00 UTC)
100,000 requests/day and 13,000 GB-s/day. Each 20 incoming WebSocket messages count as 1 request. A player sends about 20 messages/s, so roughly 1 request/s per connected player: about 25 player-hours per day free. Past that the server refuses new work until the reset (or upgrade to the $5/mo plan).

## Notes
- Not run on the real Cloudflare runtime here (no access from the build sandbox). The room logic was tested against a stand-in; the first real deploy is the true test.
- The leaderboard is kept in the Durable Object's storage and survives restarts.

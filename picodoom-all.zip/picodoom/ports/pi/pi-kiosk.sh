#!/usr/bin/env bash
# Try Pico Doom on Raspberry Pi: fullscreen kiosk.   bash pi-kiosk.sh          -> play now
#                                                     bash pi-kiosk.sh install  -> start on every desktop login
DIR="$(cd "$(dirname "$0")" && pwd)"; GAME="$DIR/trypicodoom.html"
[ -f "$GAME" ] || { echo "Put trypicodoom.html in the same folder as this script."; exit 1; }
BR=$(command -v chromium-browser || command -v chromium)
if [ -z "$BR" ]; then sudo apt-get update && sudo apt-get install -y chromium-browser || sudo apt-get install -y chromium; BR=$(command -v chromium-browser || command -v chromium); fi
if [ "$1" = install ]; then
  mkdir -p ~/.config/autostart
  printf '[Desktop Entry]\nType=Application\nName=Try Pico Doom\nExec=bash %s/pi-kiosk.sh\n' "$DIR" > ~/.config/autostart/trypicodoom.desktop
  echo "Installed. The game will start on next login. Play now with: bash $DIR/pi-kiosk.sh"; exit 0
fi
exec "$BR" --kiosk --autoplay-policy=no-user-gesture-required --noerrdialogs --disable-infobars --check-for-update-interval=31536000 "file://$GAME?res=2"

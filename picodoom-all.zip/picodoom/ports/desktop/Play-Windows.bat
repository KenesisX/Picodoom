@echo off
rem Opens Try Pico Doom in its own fullscreen window (Edge ships with Windows). Press F11 to leave fullscreen.
set "F=%~dp0trypicodoom.html"
if not exist "%F%" ( echo Put trypicodoom.html next to this file. & pause & exit /b )
start "" msedge --app="file:///%F:\=/%" --start-fullscreen
if errorlevel 1 start "" "%F%"

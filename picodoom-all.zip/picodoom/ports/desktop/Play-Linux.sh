#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"; G="$DIR/trypicodoom.html"
[ -f "$G" ] || { echo "Put trypicodoom.html next to this file."; exit 1; }
for b in google-chrome chromium chromium-browser microsoft-edge; do command -v $b >/dev/null && exec $b --app="file://$G" --start-fullscreen; done
exec xdg-open "$G"

#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
[ -f "$DIR/trypicodoom.html" ] || { echo "Put trypicodoom.html next to this file."; exit 1; }
open -na "Google Chrome" --args --app="file://$DIR/trypicodoom.html" --start-fullscreen 2>/dev/null || open "$DIR/trypicodoom.html"
